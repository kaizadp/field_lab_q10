Soil respiration database-spreadsheet calculations
Updated: 10-December-2013

Each file in this directory is an Excel spreadsheet used to estimate soil respiration (or some other datum) from one of the database studies. For example, sometimes a study will show monthly soil respiration in a figure but not compute an annual flux, and so estimates made from the figure, and resulting annual flux number, would be recorded here.

Files are named following the PDFs, and start with a four-digit study number that indexes into the srdb-studies and srdb-data files.

They are very simple and should be easily opened by OpenOffice, etc.
